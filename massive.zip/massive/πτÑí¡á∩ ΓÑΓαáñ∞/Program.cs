﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace учебная_тетрадь
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] i = new int[3];
            i[0] = 1;
            i[1] = 2;
            i[2] = 3;
            int[] j = new int[3];
            Array.Copy(i, j, 3);
            string u = "terd";


            for (int i2 = 0; i2 < i.Length; i2++)
            {
                Console.Write($"{i[i2]},");

            }
         Console.WriteLine(u);  
         Console.ReadKey();
           


            
        }   
    }
}
