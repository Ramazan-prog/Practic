﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Summ_matrix
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите количество строк: ");

            int a = int.Parse(Console.ReadLine());
            Console.Write("Введите количество столбцов: ");
            int b = int.Parse(Console.ReadLine());
            Random r = new Random();

            int[,] matrix = new int[a, b];
            Console.Write("Матрица 1: ");
            for (int i = 0; i < a; i++)
            {
                for (int j = 0; j < b; j++)
                {
                    matrix[i, j] = r.Next(1, 5);
                    Console.Write($"{matrix[i, j]}, ");
                    
                }
                

            }

            Console.WriteLine();
            
            
            int[,] matrix2 = new int[a, b];
            Console.Write("Матрица 2: ");
            for (int i = 0; i < a; i++)
            {
                for (int j = 0; j < b; j++)
                {
                    matrix2[i, j] = r.Next(1, 5);
                    Console.Write($"{matrix2[i, j]}, ");                     
                    
                }
                

            }            
            
            Console.WriteLine();

            Console.Write("Сумма матриц: ");
            int[,] matrix3 = new int[a, b];
            for (int i = 0; i < a; i++)
            {
                 for (int j = 0; j < b; j++)
                 {
                    matrix3[i,j] = matrix[i,j] + matrix2[i,j];
                    Console.Write($"{matrix3[i,j]}, ");
                    
                 }
            }
            Console.ReadKey();   



        }

    }
}
