﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace massive
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите количество строк: ");
            
            int a=int.Parse(Console.ReadLine());
            Console.Write("Введите количество столбцов: ");
            int b = int.Parse(Console.ReadLine());
            int summ = 0;
            Random r =new Random();    

            int [,] matrix= new int [ a, b ];
            for(int i =0; i < a; i++) 
            {
                for (int j = 0; j < b; j++)
                {
                    matrix[i, j] = r.Next(1,10);
                    Console.WriteLine($"{matrix[i, j]}");
                    Console.ReadKey();
                    summ += matrix [i, j];
                }
                    
            }
            
            Console.WriteLine($"Сумма = {summ}");
            Console.ReadKey();
        }   
        


        
    }
}
